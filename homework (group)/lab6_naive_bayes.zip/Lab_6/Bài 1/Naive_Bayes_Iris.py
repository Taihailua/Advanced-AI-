import pandas as pd
import numpy as np
from random import shuffle

# Đọc dữ liệu

df = pd.read_csv("Iris.csv")
df.drop(['Id'], axis=1, inplace=True)

# Xáo trộn dữ liệu
data_set = df.values.tolist()
shuffle(data_set)

# Chia thành train/test là 8/2
split = int(len(data_set) * 0.8)
train_list = data_set[:split]
test_list = data_set[split:]

columns = df.columns
train_df = pd.DataFrame(train_list, columns=columns)
test_df = pd.DataFrame(test_list, columns=columns)

# Tạo dict cho train và test
train_data = {}
test_data = {}

for species in train_df['Species'].unique():
    subset_train = train_df[train_df['Species'] == species]
    train_data[species] = {
        'SepalLengthCm': subset_train['SepalLengthCm'].tolist(),
        'SepalWidthCm':  subset_train['SepalWidthCm'].tolist(),
        'PetalLengthCm': subset_train['PetalLengthCm'].tolist(),
        'PetalWidthCm':  subset_train['PetalWidthCm'].tolist()
    }

for species in test_df['Species'].unique():
    subset_test = test_df[test_df['Species'] == species]
    test_data[species] = {
        'SepalLengthCm': subset_test['SepalLengthCm'].tolist(),
        'SepalWidthCm':  subset_test['SepalWidthCm'].tolist(),
        'PetalLengthCm': subset_test['PetalLengthCm'].tolist(),
        'PetalWidthCm':  subset_test['PetalWidthCm'].tolist()
    }

# Các hàm tính mean, variance và pdf
def mean(lst):
    return sum(lst) / len(lst)

def variance(lst, mean_val):
    return sum((x - mean_val)**2 for x in lst) / len(lst)

def the_pdf(x, mean_val, var_val):
    return 1 / (np.sqrt(2 * np.pi * var_val)) * np.exp(-((x - mean_val)**2) / (2 * var_val))


# Hàm test chaỵ naive bayes cho bộ dữ liệu
def test_nb(train_data, test_data):
    correct = 0
    total = 0

    # Tính mean và variance từ tập train
    mean_data = {}
    var_data = {}
    for species, columns in train_data.items():
        mean_data[species] = {}
        var_data[species] = {}
        for col, values in columns.items():
            m = mean(values)
            v = variance(values, m)
            mean_data[species][col] = m
            var_data[species][col] = v

    # Tính prior
    total_train = sum(len(cols['SepalLengthCm']) for cols in train_data.values())
    prior = {species: len(cols['SepalLengthCm']) / total_train for species, cols in train_data.items()}

    # Duyệt qua test_data
    for species, columns in test_data.items():
        n_samples = len(columns['SepalLengthCm'])
        for i in range(n_samples):
            sample = {col: columns[col][i] for col in columns}

            # Tính điểm cho mỗi mẫu bằng cách nhân prior với pdf của từng đặc trưng
            probs = {}
            for s in train_data.keys():
                prob = prior[s]
                for col in sample.keys():
                    prob *= the_pdf(sample[col], mean_data[s][col], var_data[s][col])
                probs[s] = prob

            # Lấy loài có xác suất cao nhất
            pred = max(probs, key=probs.get)

            # Tính xác suất
            if pred == species:
                correct += 1
            total += 1

    accuracy = correct / total
    print(f"Accuracy trên tập test: {accuracy * 100:.2f}%")

test_nb(train_data, test_data)
