import pandas as pd
import numpy as np
from random import shuffle

# Đọc dữ liệu UCI Letter-Recognition

df = pd.read_csv("letter-recognition.data", header=None)
columns = ['Class'] + [f'Feature{i}' for i in range(1, 17)]
df.columns = columns

# Xáo trộn dữ liệu
data_set = df.values.tolist()
shuffle(data_set)

# Chia train/test 80%-20%
split = int(len(data_set) * 0.8)
train_list = data_set[:split]
test_list = data_set[split:]

# Chuyển lại DataFrame
train_df = pd.DataFrame(train_list, columns=columns)
test_df = pd.DataFrame(test_list, columns=columns)

# Tạo dict train_data / test_data theo class
train_data = {}
test_data = {}

for cls in train_df['Class'].unique():
    subset_train = train_df[train_df['Class'] == cls]
    train_data[cls] = {col: subset_train[col].tolist() for col in subset_train.columns if col != 'Class'}

for cls in test_df['Class'].unique():
    subset_test = test_df[test_df['Class'] == cls]
    test_data[cls] = {col: subset_test[col].tolist() for col in subset_test.columns if col != 'Class'}

# Hàm tính mean, variance và PDF Gaussian
def mean(lst):
    return sum(lst) / len(lst)

def variance(lst, mean_val):
    return sum((x - mean_val)**2 for x in lst) / len(lst)

def the_pdf(x, mean_val, var_val):
    if var_val == 0:
        var_val = 1e-6  # tránh chia cho 0
    return 1 / (np.sqrt(2 * np.pi * var_val)) * np.exp(-((x - mean_val)**2) / (2 * var_val))

# Hàm test Naive Bayes
def test_nb(train_data, test_data):
    correct = 0
    total = 0

    # Tính mean và variance từ tập train
    mean_data = {}
    var_data = {}
    for cls, columns in train_data.items():
        mean_data[cls] = {}
        var_data[cls] = {}
        for col, values in columns.items():
            m = mean(values)
            v = variance(values, m)
            mean_data[cls][col] = m
            var_data[cls][col] = v

    # Tính prior
    total_train = sum(len(cols[list(cols.keys())[0]]) for cols in train_data.values())
    prior = {cls: len(cols[list(cols.keys())[0]]) / total_train for cls, cols in train_data.items()}

    # Duyệt test_data
    for cls, columns in test_data.items():
        n_samples = len(columns[list(columns.keys())[0]])
        for i in range(n_samples):
            sample = {col: columns[col][i] for col in columns}

            # Tính xác suất mỗi class
            probs = {}
            for c in train_data.keys():
                prob = prior[c]
                for col in sample.keys():
                    prob *= the_pdf(sample[col], mean_data[c][col], var_data[c][col])
                probs[c] = prob

            # Lấy class có xác suất cao nhất
            pred = max(probs, key=probs.get)
            if pred == cls:
                correct += 1
            total += 1

    accuracy = correct / total
    print(f"Accuracy trên tập test: {accuracy * 100:.2f}%")

# Chạy test
test_nb(train_data, test_data)
